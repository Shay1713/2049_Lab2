/************** ECE 2049 LAB 2 ******************/
/**************  4 APRIL 2023   ******************/


#include <msp430.h>
#include "peripherals.h"
#include <stdio.h>
#include <stdlib.h>


// Declare globals here
unsigned char currKey=0;
unsigned int length = 32;
unsigned int currentLength = 4;
unsigned int currentIndex = 0;
int arrayIndex = 0;
char note1;
int count;
int i = 0;

// Functions
void swDelay2(char numLoops);
void sendSimon(int sequence, int length);
int loadSequence(int sequence, int count);
void printNum(char input);
void printNum(char input);
void countDown(void);
void time2(int numLoops2, int c);
int ledDecimal(int binaryInput);
void S1toS4toLEDs(void);

//unsigned char dispSz = 0;


enum GAME_STATE {WELCOME, STARTING, SEQUENCE, SONGCHOICE, INPUT, GAMEOVER, RESTART, WIN};

// Main
void main(void)

{
    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                     // You can then configure it properly, if desired

    // Useful code starts here
    initLeds();
    configDisplay();
    configKeypad();

    Graphics_clearDisplay(&g_sContext); // Clear the display
    Graphics_flushBuffer(&g_sContext);
    Graphics_drawStringCentered(&g_sContext, "HERO", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT); // instructing player
    Graphics_drawStringCentered(&g_sContext, "Press '*'", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT); // instructing player
    Graphics_flushBuffer(&g_sContext);

    char sequence[36] = {'d', 'b', 'b', 'c', 'b', 'b', 'a', 'a', 'd', 'd', 'a', 'a', 'a', 'b', 'a', 'a', 'g', 'g', 'd', 'b', 'b', 'b', 'c', 'b', 'a', 'a', 'd', 'd', 'a', 'a', 'a', 'b', 'a', 'a', 'g', 'g'};

    enum GAME_STATE state = WELCOME;

    while (1)
    {
        S1toS4toLEDs();

        // Check if any keys have been pressed on the 3x4 keypad
        currKey = getKey();

        if (currKey == '#') { // to restart game at any time
            state = RESTART;
        }

        switch (state) {

            case WELCOME:
                currKey = getKey();
                Graphics_drawStringCentered(&g_sContext, "HERO", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "Press '*'", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT); // instructing player
                Graphics_flushBuffer(&g_sContext);
                if (currKey == '*') {
                    state = SONGCHOICE;
                }
            break;

            case SONGCHOICE:
                BuzzerOn();
                Graphics_drawStringCentered(&g_sContext, "Song Choices", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "Today Are ...", AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay2(5);
                BuzzerOff();
                Graphics_clearDisplay(&g_sContext); // Clear the display
                Graphics_flushBuffer(&g_sContext);
                BuzzerOn();
                Graphics_drawStringCentered(&g_sContext, "Hush Little Baby", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT); // instructing player
                //Graphics_drawStringCentered(&g_sContext, "&", AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT); // instructing player
                //Graphics_drawStringCentered(&g_sContext, "Baby Shark", AUTO_STRING_LENGTH, 48, 55, TRANSPARENT_TEXT); // instructing player
                Graphics_flushBuffer(&g_sContext);
                swDelay2(4);
                BuzzerOff();
                Graphics_clearDisplay(&g_sContext); // Clear the display
                Graphics_flushBuffer(&g_sContext);
                state = STARTING;
            break;

            case STARTING:
                countDown();
               state = SEQUENCE;

            break;

            case SEQUENCE:
                for (i = 0; i < currentLength; i++) {

                        if (sequence[i] == 'a') {
                            BuzzerOnControl(440);
                            setLeds('8' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "a", AUTO_STRING_LENGTH, 20, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '1'; // for me the note is 1
                        } if (sequence[i] == 'B') { // b flat
                            BuzzerOnControl(698);
                            setLeds('8' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "B", AUTO_STRING_LENGTH, 60, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '1'; // for me the note is 1
                        } if (sequence[i] == 'b') {
                            BuzzerOnControl(494);
                            setLeds('8' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "b", AUTO_STRING_LENGTH, 20, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '1'; // for me the note is 1
                        } if (sequence[i] == 'c') {
                            BuzzerOnControl(523);
                            setLeds('4' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "c", AUTO_STRING_LENGTH, 40, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '2'; // for me the note is 2
                        } if (sequence[i] == 'C') {
                            BuzzerOnControl(523);
                            setLeds('4' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "C", AUTO_STRING_LENGTH, 40, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '2'; // for me the note is 2
                        } if (sequence[i] == 'd') {
                            BuzzerOnControl(587);
                            setLeds('4' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "d", AUTO_STRING_LENGTH, 40, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '2'; // for me the note is 2
                        } if (sequence[i] == 'e') {
                            BuzzerOnControl(659);
                            setLeds('2' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "e", AUTO_STRING_LENGTH, 60, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '3'; // for me the note is 3
                        } if (sequence[i] == 'F') { // f sharp
                            BuzzerOnControl(698);
                            setLeds('2' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "F", AUTO_STRING_LENGTH, 60, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '3'; // for me the note is 3
                        } if (sequence[i] == 'f') {
                            BuzzerOnControl(698);
                            setLeds('2' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "f", AUTO_STRING_LENGTH, 60, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '3'; // for me the note is 3
                        } if (sequence[i] == 'g') {
                            BuzzerOnControl(784);
                            setLeds('1' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "g", AUTO_STRING_LENGTH, 80, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '4'; // for me the note is 4
                        } if (sequence[i] == 'Z') { // A flat
                            BuzzerOnControl(831);
                            setLeds('1' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "A", AUTO_STRING_LENGTH, 80, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '4'; // for me the note is 4
                        }   if (sequence[i] == 'A') { // A2
                            BuzzerOnControl(831);
                            setLeds('1' - 0x30);
                            Graphics_drawStringCentered(&g_sContext, "A", AUTO_STRING_LENGTH, 80, 50, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            note1 = '4'; // for me the note is 4
                        }
                        if (i == 35) {
                            state = WIN;
                        }

                        swDelay2(3);
                        BuzzerOff();
                        setLeds(0);
                        swDelay2(3);
                        Graphics_clearDisplay(&g_sContext);
                        Graphics_flushBuffer(&g_sContext);
                }

                state = INPUT;
                currentIndex = 0;
                Graphics_drawStringCentered(&g_sContext, "Repeat", AUTO_STRING_LENGTH, 55, 35, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay2(1);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);

            break;

            case INPUT:
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                printNum(currKey);

                if ((currKey == '1') && (sequence[currentIndex] == ('a' | 'b' | 'B'))) { // if 1 is pressed correctly
                    currentIndex++;
                } else if ((currKey == '2') && (sequence[currentIndex] == ('c' | 'C' |'d'))) { // if 2 is pressed correctly
                    currentIndex++;
                } else if ((currKey == '3') && (sequence[currentIndex] == ('e'|'f' | 'F'))) { // if 3 is pressed correctly
                    currentIndex++;
                } else if ((currKey == '4') && (sequence[currentIndex] == ('g'|'Z' |'A'))) { // if 4 is pressed correctly
                    currentIndex++;
                } else if ((currKey == '1') && (sequence[currentIndex] == ('c' | 'C' | 'd' | 'e' | 'f' |'F'| 'g' | 'Z' |'A'))) { // if 1 pressed wrong
                    state = GAMEOVER;
                } else if ((currKey == '2') && (sequence[currentIndex] == ('a' | 'b' | 'B'| 'e' | 'f' |'F'| 'g' | 'Z' |'A'))) { // if 2 pressed wrong
                    state = GAMEOVER;
                } else if ((currKey == '3') && (sequence[currentIndex] == ('a' | 'b' | 'B'| 'c' |'C'| 'd' | 'g' | 'Z' | 'A'))) { // if 3 pressed wrong
                    state = GAMEOVER;
                } else if ((currKey == '4') && (sequence[currentIndex] == ('a' | 'b' |'B'| 'c' |'C'| 'd' | 'e' | 'f' |'F'))) { // if 4 pressed wrong
                    state = GAMEOVER;
                }

                if (currentLength - currentIndex == 0) {
                    state = SEQUENCE;
                    currentLength++;
                }

                swDelay2(1);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
            break;

            case GAMEOVER:
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "GAME OVER", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "YOU LOSE", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext); // refresh
                swDelay2(5);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                state = WELCOME;
            break;

            case RESTART:
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "RESTART", AUTO_STRING_LENGTH, 50, 25, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "PROCESSING", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "...", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext); // refresh
                setLeds(0);
                swDelay2(4);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                state = WELCOME;
           break;

           case WIN:
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "CONGRATS", AUTO_STRING_LENGTH, 50, 25, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "YOU WON", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "HERO", AUTO_STRING_LENGTH, 50, 45, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext); // refresh
                for (count = 20; count > 0; count--){
                    setLeds('8' - 0x30);
                    setLeds('4' - 0x30);
                    setLeds('2' - 0x30);
                    setLeds('1' - 0x30);
                }
                setLeds(0);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                state = WELCOME;
           break;
        }


    }  // end while (1)
}


// FUNCTIONS START HERE


void countDown(void) {
    setLeds('3' - 0x30);
    BuzzerOn();
    Graphics_drawStringCentered(&g_sContext, "3", AUTO_STRING_LENGTH, 20, 55, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);
    swDelay2(2);
    BuzzerOff();
    swDelay2(2);
    setLeds('2' - 0x30);
    BuzzerOn();
    Graphics_drawStringCentered(&g_sContext, "2", AUTO_STRING_LENGTH, 40, 55, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);
    swDelay2(2);
    BuzzerOff();
    swDelay2(2);
    setLeds('1' - 0x30);
    BuzzerOn();
    Graphics_drawStringCentered(&g_sContext, "1", AUTO_STRING_LENGTH, 60, 55, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);
    swDelay2(2);
    BuzzerOff();
    swDelay2(2);
    setLeds('7'-0x30);
    BuzzerOn();
    Graphics_drawStringCentered(&g_sContext, "GO", AUTO_STRING_LENGTH, 80, 55, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);
    swDelay2(2);
    BuzzerOff();
    setLeds(0);
    swDelay2(2);
    Graphics_clearDisplay(&g_sContext);
    Graphics_flushBuffer(&g_sContext);
}

void printNum(char input) {
    unsigned char dispThree[3];
    unsigned char dispSz = 3;
    dispThree[0] = ' ';
    dispThree[2] = ' ';

    if ((input >= '1') && (input <= '4')) {
        dispThree[1] = input;
    }
    if (input == '1') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 12, 55, OPAQUE_TEXT);

    } else if (input == '2') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 36, 55, OPAQUE_TEXT);

    } else if (input == '3') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 60, 55, OPAQUE_TEXT);

    } else if (input == '4') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 84, 55, OPAQUE_TEXT);
    }
    Graphics_flushBuffer(&g_sContext);

}


void swDelay2(char numLoops)
{
    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}

int ledDecimal(int binaryInput){
    if (binaryInput == 1) {
        return 8;
    }
    if (binaryInput == 2){
        return 4;
    }
    if (binaryInput == 3){
        return 2;
    }
    if (binaryInput == 4){
        return 1;
    } return 0;
}

void S1toS4toLEDs(void) // Me setting the buttons to light the LEDs
{
    currKey = getKey();
        if (currKey == '1') { // S1
            //printf("button %c pressed\n", currKey);
            setLeds('8' - 0x30);

        }
        if (currKey == '2') { // S2
            //printf("button %c pressed\n", currKey);
            setLeds('4' - 0x30);

        }
        if (currKey == '3') { // S3 pressed
            //printf("button %c pressed\n", currKey);
            setLeds('2' - 0x30);


        }
        if (currKey == '4') { // S4 pressed
            //printf("button %c pressed\n", currKey);
            setLeds('1' - 0x30);

        }
        if (currKey == '7') {
            //printf("button %c pressed\n", currKey);
            setLeds('0' - 0x30);
        }
}

