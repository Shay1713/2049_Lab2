/************** ECE2049 DEMO CODE ******************/
/**************  13 March 2019   ******************/
/***************************************************/

#include <msp430.h>
#include "peripherals.h"
#include <stdio.h>
#include <stdlib.h>


// GLOBAL VARIABLES

unsigned char currKey;
unsigned char currKey2;
unsigned int length = 32;
char noteLED = '9';
//unsigned int playerInput[length];
unsigned int currentLength = 0;
unsigned int currentIndex = 0;
int button = 0;
int count; // counter
int pitch;
int duration;
int maxSongHB = 28;
int maxSongBS = 32;
int maxSongChoice;
unsigned char noteNow;
unsigned char number;
unsigned char note1;
unsigned char note2;
unsigned char note11;
unsigned char dispThree[3];
unsigned char happyBirthday[] = {'g', 'g', 'a', 'g', 'c', 'b', 'g', 'g', 'a', 'g', 'd', 'c', 'g', 'g', 'g', 'e', 'c', 'b', 'a', 'f', 'f', 'e', 'c', 'd', 'c', 'c', 'c', 'c'}; // song 1
unsigned char babyShark[] = {'c', 'd', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'c', 'd', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'c', 'd', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'e'}; // song 2
unsigned char playerIndex[];
int arrayIndex;
int arrayIndexP;

// FUNCTION PROTOTYPES

void swDelay2(char numLoops);
void sendSimon(int sequence, int length);
int loadSequence(int sequence, int count);
void printNum(char input);
void printNum(char input);
void countDown(void);
int ledDecimal(int binaryInput);
void notesToLEDs(char note); // lab2
void S1toS4toLEDs(void); // lab 2
void buttonPresses (void);
void babySharkReset(void);
void happyBirthdayReset(void);
unsigned char dispSz = 0;





// Declare states here
enum GAME_STATE {WELCOME, STARTING, SONG_SELECTION, SONG1, SONG2, SEQUENCE1, SEQUENCE2, INPUT1, INPUT2, CHECKING1, CHECKING2, GAMEOVER, WINNING, RESTART};


// Main
void main(void)

{
    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. always need to stop this!!
                                     // You can then configure it properly, if desired


    // Useful code starts here
    initLeds();
    configDisplay();
    configKeypad();
    configS1toS4(); // lab 2��


    Graphics_clearDisplay(&g_sContext); // Clear the display
    Graphics_drawStringCentered(&g_sContext, "HERO", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT); // instructing player
    Graphics_drawStringCentered(&g_sContext, "Press '*'", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT); // instructing player
    Graphics_flushBuffer(&g_sContext);

    enum GAME_STATE state = WELCOME;




    while (1)    // Forever loop
    {


        // Check if any keys have been pressed on the 3x4 keypad
        currKey = getKey();

        //S1toS4toLEDs();

        // STATE CHANGES START HERE

        if (currKey == '#') { // restart requirement
            state = RESTART;
        }
        if (currKey == '5') { // restart requirement
            state = WELCOME;
        }



        switch (state) {

            case WELCOME:
                currentIndex = 0;
                currentLength = 0;
                arrayIndex = 0;
                setLeds(0);
                currKey = getKey();
                Graphics_drawStringCentered(&g_sContext, "HERO", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "Press '*'", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT); // instructing player
                Graphics_flushBuffer(&g_sContext);
                if (currKey == '*') {
                    Graphics_clearDisplay(&g_sContext); // Clear the display
                    state = STARTING;
                }
            break;

            case STARTING:
                BuzzerOn();
                Graphics_drawStringCentered(&g_sContext, "Song Choices", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "Today Are ...", AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay2(5);
                BuzzerOff();
                Graphics_clearDisplay(&g_sContext); // Clear the display
                Graphics_flushBuffer(&g_sContext);
                BuzzerOn();
                Graphics_drawStringCentered(&g_sContext, "Happy Birthday", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT); // instructing player
                Graphics_drawStringCentered(&g_sContext, "&", AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT); // instructing player
                Graphics_drawStringCentered(&g_sContext, "Baby Shark", AUTO_STRING_LENGTH, 48, 55, TRANSPARENT_TEXT); // instructing player
                Graphics_flushBuffer(&g_sContext);
                swDelay2(4);
                BuzzerOff();
                Graphics_clearDisplay(&g_sContext); // Clear the display
                Graphics_flushBuffer(&g_sContext);
                state = SONG_SELECTION;

            break;

            case SONG_SELECTION:
                currKey = getKey();
                setLeds('6');
                Graphics_drawStringCentered(&g_sContext, "Press '8' for ", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT); // instructing player
                Graphics_drawStringCentered(&g_sContext, "Happy Birthday", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT); // instructing player
                Graphics_drawStringCentered(&g_sContext, "Press '0' for", AUTO_STRING_LENGTH, 48, 65, TRANSPARENT_TEXT); // instructing player
                Graphics_drawStringCentered(&g_sContext, "Baby Shark", AUTO_STRING_LENGTH, 48, 75, TRANSPARENT_TEXT); // instructing player
                Graphics_flushBuffer(&g_sContext);

                if (currKey == '8'){
                    setLeds(0);
                    Graphics_clearDisplay(&g_sContext); // Clear the display
                    maxSongChoice = maxSongHB;
                    state = SONG1;
                }
                else if (currKey == '0'){
                    setLeds(0);
                    Graphics_clearDisplay(&g_sContext); // Clear the display
                    maxSongChoice = maxSongBS;
                    state = SONG2;
                }

            break;

            case SONG1:
                Graphics_clearDisplay(&g_sContext); // Clear the display
                setLeds('1'-0x30);
                Graphics_drawStringCentered(&g_sContext, "Happy Birthday", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay2(2);
                setLeds(0);
                countDown();
                count = 0;
                state = SEQUENCE1;

            break;

            case SONG2:
                Graphics_clearDisplay(&g_sContext); // Clear the display
                setLeds('2'-0x30);
                Graphics_drawStringCentered(&g_sContext, "Baby Shark", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay2(2);
                setLeds(0);
                countDown();
                count = 0;
                state = SEQUENCE2;
            break;

            case SEQUENCE1: // do song 1 stuff

                note1 = happyBirthday[count];
                notesToLEDs(note1); // sets number variable
                currentLength++; //currentLength++
                printf("seq1 note1 is %c and count is %d and currentLength is %d\n", note1, count, currentLength);
                state = INPUT1;


            break;

            case SEQUENCE2: // do song 2 stuff

                note1 = babyShark[count];
                notesToLEDs(note1); // sets number variable
                currentLength++; //currentLength++
                printf("seq1 number is %c and count is %d and currentLength is %d\n", number, count, currentLength);
                state = INPUT2;


            break;

            case INPUT1:

                buttonPresses();

                printf("input1 currentIndex is %d\n", currentIndex);
                if (currentIndex == currentLength) {
                    state = CHECKING1;
                }

            break;

            case INPUT2:

                buttonPresses();

                printf("input2 currentIndex is %d\n", currentIndex);
                if (currentIndex == currentLength) {
                    state = CHECKING2;
                }

            break;

            case CHECKING1:
                if (playerIndex[count] == number){
                        count++;
                        printf("equal count %d\n", count);
                        state = SEQUENCE1;
                }
                else {
                        count = 0;
                        state = GAMEOVER;
                }

            break;

            case CHECKING2:

                if (playerIndex[count] == number){
                    count++;
                    printf("equal count %d\n", count);
                    state = SEQUENCE2;
                }
                else {
                    count = 0;
                    state = GAMEOVER;
                }


            break;

            case GAMEOVER:
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "GAME OVER", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "YOU LOSE", AUTO_STRING_LENGTH, 50, 45, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext); // refresh
                swDelay2(5);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                currentIndex = 0;
                currentLength = 0;
                arrayIndex = 0;
                setLeds(0);
                babySharkReset();
                happyBirthdayReset();
                state = WELCOME;
            break;

            case WINNING:
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "YOU WON", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "CONGRADULATIONS", AUTO_STRING_LENGTH, 50, 45, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext); // refresh
                currentIndex = 0;
                currentLength = 0;
                arrayIndex = 0;
                babySharkReset();
                happyBirthdayReset();
                for (count = 10; count >0; count--){
                    setLeds('4' - 0x30);
                    setLeds('3' - 0x30);
                    setLeds('2' - 0x30);
                    setLeds('1' - 0x30);
                } setLeds(0);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                state = WELCOME;
            break;

            case RESTART:
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "RESTART", AUTO_STRING_LENGTH, 50, 25, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "PROCESSING", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "...", AUTO_STRING_LENGTH, 50, 35, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext); // refresh
                swDelay2(5);
                Graphics_clearDisplay(&g_sContext);
                Graphics_flushBuffer(&g_sContext);
                currentIndex = 0;
                currentLength = 0;
                arrayIndex = 0;
                babySharkReset();
                happyBirthdayReset();
                setLeds(0);
                state = WELCOME;
           break;
        }


    }  // end while (1)
}

void countDown(void) { // still need to configure to be run by the timer
    int i;
    //unsigned char dispThree[3];
    dispThree[0] = ' ';
    dispThree[2] = ' ';

    for (i = 3; i > 0; i--) {
        if(i == 1){
            Graphics_clearDisplay(&g_sContext); // Clear
            Graphics_drawStringCentered(&g_sContext, "1" , AUTO_STRING_LENGTH, 50, 45, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext); // flush
        }
        if(i == 2){
            Graphics_clearDisplay(&g_sContext); // Clear
            Graphics_drawStringCentered(&g_sContext, "2" , AUTO_STRING_LENGTH, 50, 45, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext); // flush
                }
        if(i == 3){
            Graphics_clearDisplay(&g_sContext); // Clear
            Graphics_drawStringCentered(&g_sContext, "3" , AUTO_STRING_LENGTH, 50, 45, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext); // flush
        }
        BuzzerOn();
        setLeds(ledDecimal(i) - 0x30);
        swDelay2(3);
        BuzzerOff();
        Graphics_clearDisplay(&g_sContext); // Clear
    }
    Graphics_clearDisplay(&g_sContext); // Clear
    BuzzerOn();
    Graphics_drawStringCentered(&g_sContext, "GO!", AUTO_STRING_LENGTH, 50, 45, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);
    setLeds('1' - 0x30);
    swDelay2(3);
    setLeds(0);
    BuzzerOff();
    Graphics_clearDisplay(&g_sContext); // Clear
    Graphics_flushBuffer(&g_sContext);

}

void printNum(char input) {
    unsigned char dispThree[3];
    unsigned char dispSz = 3;
    dispThree[0] = ' ';
    dispThree[2] = ' ';

    if ((input >= '1') && (input <= '4')) {
        dispThree[1] = input;
    }
    if (input == '1') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 12, 55, OPAQUE_TEXT);

    } else if (input == '2') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 36, 55, OPAQUE_TEXT);

    } else if (input == '3') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 60, 55, OPAQUE_TEXT);

    } else if (input == '4') {
        Graphics_drawStringCentered(&g_sContext, dispThree, dispSz, 84, 55, OPAQUE_TEXT);
    }
    Graphics_flushBuffer(&g_sContext);

}



void swDelay2(char numLoops)
{
    volatile unsigned int i,j;
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;
        while (i > 0)
           i--;
    }
}

int ledDecimal(int binaryInput){
    if (binaryInput == 1) {
        return 8;
    }
    if (binaryInput == 2){
        return 4;
    }
    if (binaryInput == 3){
        return 2;
    }
    if (binaryInput == 4){
        return 1;
    } return 0;

}

void S1toS4toLEDs(void) // Me setting the buttons to light the LEDs
{
    currKey = getKey();
        if (currKey == '1') { // S1
            //printf("button %c pressed\n", currKey);
            setLeds('8' - 0x30);

        }
        if (currKey == '2') { // S2
            //printf("button %c pressed\n", currKey);
            setLeds('4' - 0x30);

        }
        if (currKey == '3') { // S3 pressed
            //printf("button %c pressed\n", currKey);
            setLeds('2' - 0x30);


        }
        if (currKey == '4') { // S4 pressed
            //printf("button %c pressed\n", currKey);
            setLeds('1' - 0x30);

        }
        if (currKey == '7') {
            //printf("button %c pressed\n", currKey);
            setLeds('0' - 0x30);
        }

}

void notesToLEDs(char note) // Me setting the pitch notes to light the LEDs
{
    number = '0';


    // A = 440 Hz   (LED 1)
        if (note == 'a') {
           setLeds('8'-0x30);
           pitch = 440;
           BuzzerOnControl(pitch);
           Graphics_drawStringCentered(&g_sContext, "a", AUTO_STRING_LENGTH, 20, 50, TRANSPARENT_TEXT);
           Graphics_flushBuffer(&g_sContext);
           number = '1';
           setLeds(0);
           BuzzerOff();
           swDelay2(1);
           Graphics_clearDisplay(&g_sContext); // Clear
        }
    // B flat = 466 Hz  (LED 1)
        if (note == 'B') {
            setLeds('8'-0x30);
            pitch = 466;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "b flat", AUTO_STRING_LENGTH, 20, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '1';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear
        }
    // B = 494 Hz   (LED 2)
        if (note == 'b') {
            setLeds('4'-0x30);
            pitch = 494;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "b", AUTO_STRING_LENGTH, 40, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '2';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear
        }
    // C = 523 Hz   (LED 3)
        if (note == 'c') {
            setLeds('2'- 0x30);
            pitch = 523;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "c", AUTO_STRING_LENGTH, 60, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '1';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear
        }
    // C sharp = 554 Hz (LED 3)
        if (note == 'C') {
            setLeds('2'- 0x30);
            pitch = 554;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "c sharp", AUTO_STRING_LENGTH, 60, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '3';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear
        }
    // D = 587 Hz   (LED 1)
        if (note == 'd') {
            setLeds('8'-0x30);
            pitch = 587;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "d", AUTO_STRING_LENGTH, 20, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '1';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear
        }
    // E flat = 622 Hz   (LED 4)
        if (note == 'E') {
            setLeds('1'-0x30);
            pitch = 622;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "e flat", AUTO_STRING_LENGTH, 80, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '4';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear
        }
    // E = 659 Hz   (LED 2)
        if (note == 'e') {
            setLeds('4'-0x30);
            pitch = 659;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "e", AUTO_STRING_LENGTH, 40, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '2';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear

        }
    // F = 698 Hz   (LED 4)
        if (note == 'f') {
            setLeds('1'-0x30);
            pitch = 698;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "f", AUTO_STRING_LENGTH, 80, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '4';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear
        }
    // F sharp = 740 Hz  (LED 2)
        if (note == 'F') {
            setLeds('4'-0x30);
            pitch = 740;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "f sharp", AUTO_STRING_LENGTH, 40, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '2';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear

        }
    // G = 784 Hz   (LED 1)
        if (note == 'g') {
            setLeds('4'-0x30);
            pitch = 784;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "g", AUTO_STRING_LENGTH, 40, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            setLeds(0);
            BuzzerOff();
            number = '2';
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear

        }
    // A flat = 831 Hz  (LED 3)
        if (note == 'A') {
            setLeds('2'-0x30);
            pitch = 831;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "a flat", AUTO_STRING_LENGTH, 60, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '3';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear

        }
    // A2 = 880 Hz   (LED 4)
        if (note == 'z') {
            setLeds('1'-0x30);
            pitch = 880;
            BuzzerOnControl(pitch);
            Graphics_drawStringCentered(&g_sContext, "a", AUTO_STRING_LENGTH, 80, 50, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            number = '4';
            setLeds(0);
            BuzzerOff();
            swDelay2(1);
            Graphics_clearDisplay(&g_sContext); // Clear


        }


}

void buttonPresses (void) {

        while(1) {
            currKey2 = getKey();
            if (currKey2 == '1'){
                playerIndex[count] = currKey2;
                //printf("index %c\n", playerIndex[count]);
                break;
            } else if (currKey2 == '2'){
                playerIndex[count] = currKey2;
                //printf("index %c\n", playerIndex[count]);
                break;
            } else if (currKey2 == '3'){
                playerIndex[count] = currKey2;
                //printf("index %c\n", playerIndex[count]);
                break;
            } else if (currKey2 == '4'){
                playerIndex[count] = currKey2;
                //printf("index %c\n", playerIndex[count]);
                break;
            }

        }
        printf("buttonPress currentIndex %d\n", currentIndex);
        currentIndex++;
}

// reset arrays
void happyBirthdayReset(void) {
    for (count = 0; count <maxSongHB; count++){
        playerIndex[count] ='\0';
    }
}
void babySharkReset(void) {
    for (count = 0; count <maxSongBS; count++){
        playerIndex[count] ='\0';
    }
}
